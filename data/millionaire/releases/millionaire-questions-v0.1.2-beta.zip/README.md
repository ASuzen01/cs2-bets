# Millionaire question bank v0.1.2 beta

Contains 18,188 retained questions, all included at the user's direction.

**Content QA is incomplete:** all records remain pending; automatic structural checks do not establish translation quality, factual correctness, ambiguity, or distractor validity. This archive is a beta release, not an editorially approved question bank. The existing 15-question round, payouts and checkpoints are unchanged.
