# Second-pass QA report — Millionaire question bank

Date: 2026-11-07
Records checked: 18,188
Approved: 0 (all remain pending)
Release gate: **QA_HOLD_NOT_FOR_PRODUCTION**

## Source totals

- opentdb: 3,984
- rubq: 1,545
- sberquad: 10,112
- original: 2,547

## Numbered stages

| Stage | Drafts |
|---:|---:|
| 1 | 1416 |
| 2 | 1482 |
| 3 | 1539 |
| 4 | 1503 |
| 5 | 1494 |
| 6 | 1572 |
| 7 | 1571 |
| 8 | 1593 |
| 9 | 1578 |
| 10 | 1564 |
| 11 | 554 |
| 12 | 532 |
| 13 | 592 |
| 14 | 583 |
| 15 | 615 |

## Automatic review flags

- `question-capitalization-copyedit`: 393
- `question-punctuation-copyedit`: 716
- `rubq-question-and-distractors-need-human-logic-review`: 1,545
- `sberquad-question-and-distractors-need-human-logic-review`: 10,112
- `translation-semantics-still-needs-human-review`: 3,984
- `wikidata-current-truth-and-distractors-need-human-review`: 2,547

## Interpretation

The checks found copyedit and content-review work that remains unresolved. A SberQuAD answer span matching its passage does not prove the question is unambiguous or that the distractors are plausible. OpenTDB translation alignment is still semantic-review work. RuBQ correct options match the raw source answer labels in the retained set; question wording, aliases and distractors still need logic review. Wikidata triples and captured Russian answer labels match the retained records, but that alone does not prove current truth or single-answer validity.

The ZIP is a versioned **review release candidate**, not an approved production release. No rows were imported into gameplay and no question was marked approved.
